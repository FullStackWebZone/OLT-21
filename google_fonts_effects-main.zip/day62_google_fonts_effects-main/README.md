### Day 62: Google Fonts Effects

#### Deployed at: https://paeshi.github.io/day62_google_fonts_effects/

#### Docs at: https://developers.google.com/fonts/docs/getting_started
