# imagePixels
pixeliser une image base 64 avec des symboles
